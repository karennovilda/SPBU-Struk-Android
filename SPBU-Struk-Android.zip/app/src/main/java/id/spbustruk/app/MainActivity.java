package id.spbustruk.app;
import android.app.Activity; import android.os.Bundle; import android.graphics.Color; import android.graphics.Typeface; import android.widget.*; import android.content.Intent;
public class MainActivity extends Activity {
 EditText pump,fuel,liter,price,cashier,trans; TextView receipt;
 public void onCreate(Bundle b){super.onCreate(b); ScrollView sc=new ScrollView(this); LinearLayout r=new LinearLayout(this); r.setOrientation(1); r.setPadding(24,24,24,24); r.setBackgroundColor(Color.rgb(245,247,250)); sc.addView(r);
 TextView h=new TextView(this); h.setText("SPBU STRUK"); h.setTextSize(26); h.setTypeface(null,Typeface.BOLD); h.setTextColor(Color.rgb(20,70,130)); r.addView(h);
 TextView sub=new TextView(this); sub.setText("Generator struk transaksi BBM"); r.addView(sub);
 pump=f(r,"Nomor pompa","1"); fuel=f(r,"Jenis BBM","Pertalite"); liter=f(r,"Volume (liter)","10"); price=f(r,"Harga per liter (Rp)","10000"); cashier=f(r,"Nama operator/kasir","Kasir"); trans=f(r,"Nomor transaksi","TRX-0001");
 Button gen=new Button(this); gen.setText("BUAT STRUK"); r.addView(gen); receipt=new TextView(this); receipt.setTextSize(16); receipt.setTextColor(Color.BLACK); receipt.setPadding(16,16,16,16); receipt.setBackgroundColor(Color.WHITE); r.addView(receipt);
 Button share=new Button(this); share.setText("BAGIKAN STRUK"); r.addView(share); gen.setOnClickListener(v->make()); share.setOnClickListener(v->{if(receipt.length()==0)make(); Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,receipt.getText().toString()); startActivity(Intent.createChooser(i,"Bagikan struk"));}); setContentView(sc); }
 EditText f(LinearLayout r,String label,String val){TextView t=new TextView(this);t.setText(label);t.setPadding(0,14,0,4);r.addView(t);EditText e=new EditText(this);e.setSingleLine(true);e.setText(val);r.addView(e);return e;}
 void make(){double l=0,p=0;try{l=Double.parseDouble(liter.getText().toString());p=Double.parseDouble(price.getText().toString());}catch(Exception e){} long total=Math.round(l*p);receipt.setText("        SPBU STRUK\n================================\nNo. Transaksi : "+trans.getText()+"\nPompa        : "+pump.getText()+"\nBBM          : "+fuel.getText()+"\nVolume       : "+liter.getText()+" L\nHarga/L      : Rp "+price.getText()+"\nTOTAL        : Rp "+String.format("%,d",total)+"\nKasir        : "+cashier.getText()+"\n================================\n      Terima kasih\n      Selamat jalan\n");}
}
