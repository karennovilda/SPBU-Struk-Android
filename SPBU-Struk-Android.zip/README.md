# SPBU Struk Android
Starter app for a simple fuel receipt generator.
Build APK via GitHub Actions. Artifact: `SPBU-Struk-APK`.
Prototype only; values are manually entered and not connected to real SPBU systems.
